"""
Módulo utils - Utilidades del sistema Sentinel Grid

✨ Sistema de utilidades y herramientas del proyecto
🛡️ Gestión de datos, logging y configuraciones
🔧 Integración completa con MT5 y análisis ICT/POI
"""
