"""
Módulo de Gestión de Riesgo - Sistema Sentinel Grid
Contiene todos los componentes de gestión de riesgo, órdenes y estrategias
"""
