"""
Módulo del Sistema - Sistema Sentinel Grid
Contiene configuración, logging y componentes centrales del sistema
"""
